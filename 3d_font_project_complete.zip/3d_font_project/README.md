# 3D Font Rendering Project

## How to Run

1. Install dependencies.
2. Run `python app.py`.

